# Submission — for authors and reviewers only

Replace each bracketed field. Do not copy this document into either runtime image.
This form is contribution metadata, not a Harbor configuration file or a proposal.

## Identity

- Task name and version: [match task/task.toml]
- Author(s), affiliation (optional), contact: [fill]
- Summary and relevant domain experience: [fill]

## Engineering value and difficulty

[What real problem is represented? What decisions require expertise? What does a
simple baseline achieve? How does this differ from existing benchmark tasks?]

## Public contract and private evaluation

[Describe inputs, outputs, units, operating envelope and public feedback. List
private scenarios/assets and how they remain outside the agent environment.]

## Scoring

[Checkpoint definitions, weights, threshold source, gate/cap, valid score range,
malformed-input behavior and numerical tolerance. Explain why metrics reflect
actual engineering success and which shortcuts they rule out.]

## Reference and baselines

- Oracle type: [full solution / protocol smoke / omitted]
- Solvability evidence and reproduction command: [fill]
- Expected reference reward range: [fill]
- Expected Nop reward range: [fill]
- Other baselines and expected results: [fill]

## Resources and dependencies

[Harbor version, CPU/GPU hardware, RAM/VRAM, disk, image/data sizes, build time,
agent and verifier runtime, approximate evaluation cost. List version pins,
licenses, data provenance, download checksums and requested network exceptions.]

## Validation evidence

| Check | Command / evidence file | Expected | Actual |
| --- | --- | --- | --- |
| Clean build and Harbor handoff | [fill] | [fill] | [fill] |
| Reference / Oracle | [fill] | [fill] | [fill] |
| Nop and malformed inputs | [fill] | [fill] | [fill] |
| Metric / golden regressions | [fill] | [fill] | [fill] |
| Repeated evaluation | [fill] | [fill] | [fill] |
| Forged metrics / cheating probes | [fill] | [fill] | [fill] |
| Agent isolation / permissions | [fill] | [fill] | [fill] |
| Real agent trial, if available | [fill] | [fill] | [fill] |

[Record seed/configuration, repeat count and observed deltas. Explain failures,
checks not run, infrastructure errors and remaining limitations.]

## Revision notes

[For a resubmission: what changed and which failed checks were rerun?]
