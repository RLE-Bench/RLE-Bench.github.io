# Author guide — not an agent instruction

Audience: people building benchmark tasks. Do not copy this document, the
submission form, local tests, or reference solutions into the agent image.
The evaluated agent receives `task/instruction.md` and the curated environment.

## 1. Define the engineering problem

Choose a realistic robotics engineering deliverable: a design, controller,
training recipe, perception system, or another objectively measurable result.
Explain what expertise it exercises and why a trivial baseline is insufficient.
State the intended CPU/GPU, memory, storage and time budget. Difficulty should
come from engineering decisions, not missing instructions or fragile tooling.

The example is intentionally easy: choose two link lengths that satisfy reach
constraints. Its analytic grader illustrates the protocol, not simulator or
training infrastructure. Replace its prompt, metrics, reference, and regression
tests together. Do not merely rename it.

## 2. Write the agent prompt

Edit **only `task/instruction.md`** for the evaluated agent. It should stand alone:

1. State the objective and engineering context.
2. Identify available tools and public assets with absolute container paths.
3. Specify deliverable paths, formats, units, coordinate conventions and schemas.
4. State allowed actions, physical constraints, budgets and runtime restrictions.
5. Explain scored behavior, weighting and validity gates at a useful public level.
6. Provide a way to exercise the public interface without exposing hidden cases.

Document everything necessary for a legitimate solution. Hidden scenarios may
sample a stated operating envelope; they must not introduce undocumented output
requirements. Do not prescribe an implementation unless it is a real constraint.
Keep exact hidden cases, private seeds, expected outputs, reference designs,
author TODOs, review instructions and acceptance reports out of this prompt.
Public schemas and representative examples are encouraged; reference answers
are not. Any public self-test is advisory, never the verifier's source of truth.

## 3. Configure Harbor

`task/task.toml` is Harbor configuration, not the website submission form.
Replace task identity, version, description, authors and metadata. Remove the
example marker once the new task and its checks are complete.

- Keep `artifacts` at the TOML top level, before any section. The example hands
  off `/logs/artifacts` to the separate verifier at the same path.
- Keep `[verifier].environment_mode = "separate"` and supply `tests/Dockerfile`.
- Declare agent and verifier timeouts independently. Declare their resources in
  `[environment]` and `[verifier.environment]`; do not rely on your workstation.
- Keep both environments offline by default. Install tools and data at build
  time. Document any requested exception and why an offline fixture cannot work.
- Request GPUs only if needed, specifying count, supported hardware and memory
  assumptions. Record the actual validation hardware in `SUBMISSION.md`.
- Avoid local prebuilt image names that only exist on your machine. The ZIP must
  build using its own contexts or documented, accessible pinned base images.

This kit targets Harbor 0.21.0. Keep the tested Harbor version in your evidence;
upgrading requires rerunning the separate-verifier handoff checks.

## 4. Build the two images

Harbor builds `environment/Dockerfile` from `environment/` and the verifier
Dockerfile from `tests/`. Neither may rely on files outside its build context.
Use explicit COPY lists. Do not broaden the agent context to include the kit.
Never put private content into an image layer and delete it in a later layer.

| Content | Location | Agent can see it? |
| --- | --- | --- |
| Prompt, public API, curated scenes, public examples | instruction.md / environment/ | Yes |
| Metrics, hidden scenarios, private assets | tests/harness/ | No |
| Reference implementation | solution/ | Only during Oracle validation |
| Author guidance, evidence, regression tests | Kit root / author_checks/ | No |

Pin runtime dependencies, simulator versions and base images. If adding MuJoCo,
use the same exact version in every relevant image and requirements file; pin
timestep, solver settings and seeds. Prefer one source for numeric thresholds.
Explain permitted numerical tolerance; do not silently broaden it to mask drift.
Avoid live datasets, private credentials, host bind mounts and external local
paths. Include resource licenses and provenance. Large assets need immutable
locations, checksums and redistribution terms; ensure the execution service can
obtain them before offline evaluation.

This standalone kit stores shipped harness code directly under `tests/harness/`.
When a contribution is integrated into an RLE-Bench family, maintainers move its
source into the family's `harness/` and stage curated image trees through
`build_assets.py`. Contributors need not clone RLE-Bench to run this kit.

## 5. Implement trustworthy scoring

`tests/test.sh` is the verifier entry point and the only writer of
`/logs/verifier/reward.json`. The example grader emits JSON on stdout; the shell
entry point writes it. Keep grading functions independently callable so author
checks do not write production reward files.

The reward object must contain a finite numeric `reward` in [0, 1], with named
checkpoint scores. Apply stage weighting and the validity gate before emitting
the total. Explain the formula, thresholds and gate in `SUBMISSION.md`; runtime
thresholds belong in one harness configuration. Infrastructure exceptions should
have a distinct error status and nonzero exit, not masquerade as valid low scores.

Treat every submitted file as untrusted. Validate schema, types, sizes and finite
numbers before physics or scoring. Define what missing and malformed submissions
earn. Do not use unsafe pickle loading or execute submitted code in the trusted
grader process. Controllers that require execution need a separate constrained
process/container and trusted instrumentation; a subprocess alone is not a
security boundary. Do not accept arbitrary paths into private resources.

Measure outcomes using verifier-owned state, simulation and data. Submitted CSVs,
plots, logs and claimed rewards may be checked for consistency but cannot become
ground truth. Tests should exercise behavior, not search for keywords in source.
Check that cheating submissions cannot receive legitimate high scores.

For physics tasks, add analytic metric tests before stability checks. Validate
the golden design at its expected score and confirm it never tips. Use FASM for
slope/uneven-contact stability; ZMP is a flat-ground cross-check. Cap continuous
rewards at calibrated targets so oversized designs gain no unlimited advantage,
and pair performance with mass/footprint budgets where appropriate.

## 6. Supply solvability evidence

`solution/` is optional in Harbor. If supplied, use absolute paths in `solve.sh`
and identify it as either a full solution or a protocol smoke check. A full
solution must reach its declared score under the task's actual resource limits.
It must construct valid deliverables, not write a reward or tamper with grading.
The example Oracle writes equal-length links as a legitimate feasible design.

If omitting the Oracle, remove `solution/`, skip `-a oracle`, and document other
reproducible solvability evidence (e.g. a reference artifact with provenance and
verifier results). A smoke check establishes handoff only. It does not establish
solvability. Golden-model and metric regressions remain required where relevant.

## 7. Validate before uploading

Run checks from the kit root; use the commands in README.md. Adapt
`author_checks/test_grading.py` to the new task, including expected values derived
independently of the implementation. The supplied checks cover known reachable
and unreachable designs, budget gating, boundary behavior and malformed inputs.
They are an example regression suite, not a general submission validator.

Record evidence for:

- Clean builds and actual Harbor artifact transfer into the separate verifier.
- Oracle or reference result, expected score range and comparison to baselines.
- Nop, missing, malformed, oversized and non-finite submissions; invalid models.
- Forged metrics and other task-specific shortcuts. Test that reported success
  cannot override the verifier's own measurement.
- Repeated evaluation of the same deliverable and seeds, including score deltas.
- Agent-image isolation: inspect COPY inputs and image layers; confirm private
  files/imports are unavailable from an ordinary evaluated-agent run. Do not use
  an Oracle run for this probe: it intentionally receives the reference solution.
- For filesystem privilege separation, run probes as the actual agent user,
  including traversal, alternate paths and exposed service APIs. Check permissions
  after startup, not only in the Dockerfile.
- At least one real agent trial when feasible. Record model/configuration, cost,
  score and failure causes; distinguish genuine difficulty from setup failure.

A useful acceptance report lists expected and actual values, reproduction steps,
logs and infrastructure failures separately. Automated rubric review can flag
ambiguity, weak tests and leaks, but does not prove isolation or task quality.
The future website must use its own trusted checks; uploaded author checks are
supporting evidence and must execute only in its untrusted workload sandbox.

## 8. Complete and package the submission

Fill every section of `SUBMISSION.md`. Use "not applicable" with a reason when
needed. No advance proposal or repository PR is required by this kit.

Include the full task, source/build inputs, author checks, licenses and compact
evidence files. Exclude API keys, `.env`, `.git`, virtual environments, caches,
job trees and unrelated datasets. Use ordinary files and directories; no symlinks,
absolute ZIP paths or `..` traversal entries. Run outputs should be summarized
or attached as separately supported evidence, not buried in the task images.

Follow README.md's ZIP command. Re-extract into a fresh directory and repeat the
local checks before uploading. Until the website exists, the ZIP is a portable
handoff artifact; there is no deployed upload endpoint or automated acceptance
claim. Website extraction and builds must treat the entire ZIP as untrusted.

## References

- [Harbor task format](https://www.harborframework.com/docs/tasks)
- [Terminal-Bench authoring workflow](https://github.com/harbor-framework/terminal-bench/blob/main/CONTRIBUTING.md)

Harbor defines the runtime format. This guide defines RLE-Bench contribution
expectations; benchmark-specific policies take precedence over examples in
external guides.
