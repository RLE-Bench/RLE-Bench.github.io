# Harbor task contribution kit

This kit is for **benchmark authors**, not the agent being evaluated. No proposal
or GitHub account is required to develop and package a task.

Start with [AUTHOR_GUIDE.md](AUTHOR_GUIDE.md). Fill in
[SUBMISSION.md](SUBMISSION.md) before submitting. Only
[task/instruction.md](task/instruction.md) is the evaluated agent's prompt.

```text
harbor-task/
├── AUTHOR_GUIDE.md       # How to author and validate a task
├── SUBMISSION.md         # Author's description and validation evidence
├── author_checks/        # Local harness regression tests; never shipped
└── task/                 # Standard, standalone Harbor task
    ├── instruction.md    # Public agent prompt
    ├── task.toml
    ├── environment/      # Agent image build context; public content only
    ├── solution/         # Optional Oracle; supplied only for Oracle runs
    └── tests/            # Separate verifier image and private harness
```

The included two-link arm design exercise is a **runnable protocol example**,
not a task at the benchmark's difficulty bar. Its Oracle is a full solution to
this example. Replace the example before submitting a new benchmark task.

## Quick start

Use Python 3.12, Docker and Harbor 0.21.0 (the RLE-Bench tooling pin). Install
Harbor in a dedicated host environment; it does not belong in either task image.
From this kit directory:

```bash
python3 -m unittest discover -s author_checks -v
harbor run -p task -a oracle --jobs-dir /tmp/rlebench-template-oracle
harbor run -p task -a nop --jobs-dir /tmp/rlebench-template-nop
```

Expected rewards: Oracle **1.0**, Nop **0.0**. Inspect each run's `result.json`
and `verifier/reward.json`; command completion alone does not prove success.
Use a new jobs directory for each independent check. An infrastructure error is
not an expected Nop failure. Initial image pulls require network access; task
execution is offline. The example uses a digest-pinned Python image and no
third-party Python dependencies.

## Package

From the kit directory, create an archive outside it:

```bash
python3 -m zipfile -c /tmp/my-task.zip README.md AUTHOR_GUIDE.md SUBMISSION.md task author_checks
```

Remove caches and run outputs first. The ZIP root must contain `task/task.toml`
and the author documents, without another enclosing directory. Include all
build inputs. This is the proposed upload contract for the future website;
this kit does not implement an upload service or server-side acceptance checker.
The inner `task/` remains usable directly by Harbor.
