"""Trusted analytic evaluation of a submitted two-link geometry."""

import json
import math
import os
from pathlib import Path
import stat

SPEC = json.loads(Path(__file__).with_name("spec.json").read_text())


def invalid():
    return {"reward": SPEC["gate_cap"], "validity": 0.0, "radial_coverage": 0.0}


def grade(design):
    if not isinstance(design, dict) or set(design) != {"link_1_m", "link_2_m"}:
        return invalid()
    lengths = [design["link_1_m"], design["link_2_m"]]
    tolerance = SPEC["tolerance_m"]
    for value in lengths:
        if type(value) not in (int, float):
            return invalid()
        if not SPEC["link_min_m"] - tolerance <= value <= SPEC["link_max_m"] + tolerance:
            return invalid()
    if sum(lengths) > SPEC["length_budget_m"] + tolerance:
        return invalid()
    inner, outer = abs(lengths[0] - lengths[1]), sum(lengths)
    low, high = SPEC["target_min_m"], SPEC["target_max_m"]
    if inner <= low + tolerance and outer >= high - tolerance:
        coverage = 1.0
    else:
        coverage = max(0.0, min(outer, high) - max(inner, low)) / (high - low)
    return {"reward": coverage, "validity": 1.0, "radial_coverage": coverage}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def evaluate(path):
    # Do not follow final-component symlinks or block on a submitted FIFO.
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        return invalid()
    with os.fdopen(fd, "rb") as source:
        if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
            return invalid()
        payload = source.read(SPEC["max_submission_bytes"] + 1)
    if len(payload) > SPEC["max_submission_bytes"]:
        return invalid()
    try:
        design = json.loads(payload, object_pairs_hook=unique_object)
    except (ValueError, UnicodeError, RecursionError):
        return invalid()
    return grade(design)


if __name__ == "__main__":
    result = evaluate(Path("/logs/artifacts/design.json"))
    assert math.isfinite(result["reward"]) and 0.0 <= result["reward"] <= 1.0
    print(json.dumps(result, allow_nan=False))
