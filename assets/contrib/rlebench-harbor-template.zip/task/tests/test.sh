#!/bin/bash
set -euo pipefail
mkdir -p /logs/verifier
if python3 -I /tests/harness/grade.py > /logs/verifier/reward.pending.json; then
    mv /logs/verifier/reward.pending.json /logs/verifier/reward.json
else
    printf '%s\n' '{"reward": 0.0, "harness_error": 1}' > /logs/verifier/reward.json
    exit 1
fi
