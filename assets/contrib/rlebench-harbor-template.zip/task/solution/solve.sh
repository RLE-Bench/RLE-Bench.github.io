#!/bin/bash
set -euo pipefail
mkdir -p /logs/artifacts
python3 -I - <<'PYTHON'
import json
from pathlib import Path

# Equal links remove the central unreachable region and use the length budget.
length_budget_m = 1.0
link_m = length_budget_m / 2
Path("/logs/artifacts/design.json").write_text(
    json.dumps({"link_1_m": link_m, "link_2_m": link_m}) + "\n"
)
PYTHON
