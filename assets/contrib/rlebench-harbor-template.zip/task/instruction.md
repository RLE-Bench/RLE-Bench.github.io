# Design a planar robot arm

Choose the lengths of two rigid links for a planar serial robot arm whose base
is at the origin. Both revolute joints rotate freely through a full turn.
Ignore collisions, link thickness, dynamics and joint torque limits.

The arm must reach every point whose distance from the origin is between
0.25 m and 0.90 m, inclusive. Each link must be between 0.10 m and 0.80 m,
inclusive; their combined length must not exceed 1.00 m.

Write `/logs/artifacts/design.json` as a JSON object with exactly two keys,
`link_1_m` and `link_2_m`, whose values are finite numbers in meters. The file
must be at most 4096 bytes. Python 3.12 is available; network access is disabled.

The verifier independently computes the arm's reachable radial interval. A valid
design receives a score equal to the fraction of the requested radial interval
it covers, from 0 to 1. Full coverage earns 1. A missing or malformed file, extra
keys, invalid link length, or exceeded combined-length budget earns 0. Bounds
are compared with an absolute numerical tolerance of 1e-9 m. Submit the design
file only; no self-reported score is needed.
