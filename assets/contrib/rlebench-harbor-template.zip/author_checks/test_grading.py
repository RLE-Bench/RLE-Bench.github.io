"""Author-side analytic regressions; never copied into the task images."""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE = importlib.util.spec_from_file_location(
    "example_grader", ROOT / "task/tests/harness/grade.py"
)
grader = importlib.util.module_from_spec(MODULE)
MODULE.loader.exec_module(grader)


class GradingTests(unittest.TestCase):
    def test_equal_links_cover_requested_interval(self):
        self.assertEqual(grader.grade({"link_1_m": 0.5, "link_2_m": 0.5})["reward"], 1)

    def test_partial_coverage(self):
        # Radius [0, .5] overlaps [.25, .9] by .25 of the requested .65 m.
        result = grader.grade({"link_1_m": 0.25, "link_2_m": 0.25})
        self.assertAlmostEqual(result["reward"], 5 / 13)

    def test_central_hole_reduces_coverage(self):
        # Radius [.6, .8] covers .2 of .65 m.
        result = grader.grade({"link_1_m": 0.7, "link_2_m": 0.1})
        self.assertAlmostEqual(result["reward"], 4 / 13)

    def test_no_coverage(self):
        result = grader.grade({"link_1_m": 0.1, "link_2_m": 0.1})
        self.assertEqual(result, {"reward": 0.0, "validity": 1.0, "radial_coverage": 0.0})

    def test_budget_gates_otherwise_full_coverage(self):
        self.assertEqual(grader.grade({"link_1_m": 0.6, "link_2_m": 0.6})["validity"], 0)

    def test_boundary_and_tolerance(self):
        self.assertEqual(grader.grade({"link_1_m": 0.575, "link_2_m": 0.325})["reward"], 1)
        self.assertEqual(grader.grade({"link_1_m": 0.5, "link_2_m": 0.50000001})["reward"], 0)

    def test_invalid_values_and_forged_reward(self):
        for bad in (None, True, "0.5", float("nan"), float("inf"), -1, 10**1000):
            with self.subTest(value=repr(bad)[:40]):
                self.assertEqual(grader.grade({"link_1_m": bad, "link_2_m": 0.5})["reward"], 0)
        for bad in ([], {}, {"link_1_m": 0.5, "link_2_m": 0.5, "reward": 1}):
            self.assertEqual(grader.grade(bad)["reward"], 0)

    def test_submission_files(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "design.json"
            self.assertEqual(grader.evaluate(path)["reward"], 0)
            for data in (b"{", b"\xff", b" " * 4097,
                         b'{"link_1_m":0.1,"link_1_m":0.5,"link_2_m":0.5}'):
                path.write_bytes(data)
                self.assertEqual(grader.evaluate(path)["reward"], 0)
            path.write_text(json.dumps({"link_1_m": 0.5, "link_2_m": 0.5}))
            self.assertEqual(grader.evaluate(path)["reward"], 1)
            link = Path(folder) / "link.json"
            link.symlink_to(path)
            self.assertEqual(grader.evaluate(link)["reward"], 0)


if __name__ == "__main__":
    unittest.main()
